/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encdec;

/*
 * Copyright (C) 2017 MCoury
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.InvalidCipherTextException;

//import com.pagosoft.plaf.PgsLookAndFeel;

@SuppressWarnings({"unused" })
public class Main
{

	public static void main(String[] args) throws InvalidKeyException, DataLengthException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, IllegalStateException, InvalidCipherTextException
	{

		
		String unencF="C:\\Users\\STUDENT\\Desktop\\ENCRYPTION DECRYPTION\\test file\\unenc\\GUI.java";
                String encF="C:\\Users\\STUDENT\\Desktop\\ENCRYPTION DECRYPTION\\test file\\enc\\GUI.java.enc";                              
                
            try {
                 //System.out.println(PwdGen.SpecPassGen("MyPassword1234", 16));
                //FileEncrypt.CBCEncrypt(0, 256, unencF, encF, "4PPy4ys24o344rPM", "Q");
                FileEncrypt.CBCDecrypt(0, 256, encF, unencF, "4PPy4ys24o344rPM", "Q");
                
                 
               
                
//System.out.println(TextEncrypt.CBCEncrypt("My name", "1234abcd1234abcd", 256, 0, "Q"));                                     
                //System.out.println(TextEncrypt.CBCDecrypt("NSG1hFebeczgcr713CoX73YWP/+eERwA/PSPhahWtoNkZWVlYmMwOGY3ZDIwNGFl", "1234abcd1234abcd", 256, 0, "Q"));
               
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }

	}

}

