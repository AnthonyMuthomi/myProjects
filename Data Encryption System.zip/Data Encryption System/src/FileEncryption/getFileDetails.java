/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FileEncryption;

import java.io.File;

/**
 *
 * @author Anthony Muthomi
 */
public class getFileDetails {
    private static String encUrl;private static String decUrl;
    public static String[][]getEncs(String un){
        encUrl = System.getProperty("user.dir")+"/files/"+un+"/encrypted";
        if(!new File(encUrl).exists())
            new File(encUrl).mkdirs();
    
        String [] encs = new File(encUrl).list();
        String [][] data = new String[encs.length][2];
        
        for(int i = 0; i<encs.length; i++){
            data[i][0] = (i+1)+"";
            data[i][1] = encs[i];
        }
        return data;
    }
    public static String[][]getDecs(String un){
        decUrl = System.getProperty("user.dir")+"/files/"+un+"/decrypted";
        
        if(!new File(decUrl).exists())
            new File(decUrl).mkdirs();
        String [] decs = new File(decUrl).list();
        String [][] data = new String[decs.length][2];
        
        for(int i = 0; i<decs.length; i++){
            data[i][0] = (i+1)+"";
            data[i][1] = decs[i];
        }
        return data;
    }
    public static void main(String [] args){
        //
    }
}
