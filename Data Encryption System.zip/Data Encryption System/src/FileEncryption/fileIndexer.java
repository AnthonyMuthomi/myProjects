package FileEncryption;


import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.ArrayList;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.security.SecureRandom;


public class fileIndexer {

public static String namefile(String dir,String fn) {

  File of;
  boolean hob,isint;
  int dotpos,cxbpos,opbpos;
  char ldot;
  String lopbStr,rcxbStr;



  of=new File(dir+"\\"+fn);
 

  if(of.exists()){

    dotpos=fn.lastIndexOf(".");
    ldot=fn.charAt(dotpos-1);

    if(!(ldot==')')){

String lwfa=dir+"\\"+fn.substring(0,dotpos)+"(";
String rwfa=")"+fn.substring(dotpos,fn.length());
String nwfa=indexFile(lwfa, rwfa, dir);
return nwfa;

    }else{

    hob=fn.contains("(");

    if(hob==false){

    String lwfb=dir+"\\"+fn.substring(0,dotpos)+"(";
String rwfb=")"+fn.substring(dotpos,fn.length());
String nwfb=indexFile(lwfb, rwfb, dir);
return nwfb;

 }else{

    cxbpos = fn.lastIndexOf(")");
    opbpos = fn.lastIndexOf("(");

    String opcStr=fn.substring(opbpos+1,cxbpos);

    isint=isint(opcStr);

    //isint=true;

    if(isint==false){

      String lwfc=dir+"\\"+fn.substring(0,dotpos)+"(";
String rwfc=")"+fn.substring(dotpos,fn.length());
String nwfc=indexFile(lwfc, rwfc, dir);
return nwfc;

         }else{

lopbStr=dir+"\\"+fn.substring(0,opbpos+1); rcxbStr=fn.substring(cxbpos,fn.length());
String newfni=indexFile(lopbStr, rcxbStr, dir);
return newfni;

    }
    }
    }
  }else{
    return dir+"\\"+fn;

  }///////////

}

 public static String dedec(String name){
        int fslashpos=0;
        int bslashpos=0;
        String binString="";
        
        if(name.contains("/")){
            fslashpos=name.lastIndexOf("/");
                    }else if(name.contains("\\")){
                        bslashpos=name.lastIndexOf("\\");
                    }else{}
        if(name.endsWith(".enc"))
            binString=".enc";
        name=name.replace(binString, "");
        name=name.substring(bslashpos, name.length()).replace("\\", "");
        name=name.substring(fslashpos, name.length()).replace("/", "");
        binString="";
        //System.out.println();
        String nameb=name.substring(name.lastIndexOf(".")+1,name.length());
        if(nameb.matches("[a-zA-Z0-9]+")){}
        else{
            
          String nos="";
            char [] namechars=nameb.toCharArray();
            for(char namechar : namechars ){
                
                if((namechar+"").matches("[a-zA-Z0-9]+")){}
                else{
                    
               int least=nameb.lastIndexOf((namechar+""));
                
                 nos+=(least+",");
                }
                 
            }
            
            if(nos.equals("")){}
            else{
                nos=nos.substring(0, nos.indexOf(","));
                int f=Integer.parseInt(nos);
                nameb=nameb.substring(0, f);
                //System.out.println(f);
            }
           
        }
                  //System.out.println(nameb); 
            
        
        name=name.substring(0, name.lastIndexOf(".")+1)+nameb;
        System.out.println(name);
        return name;
    }

public static String indexFile(String lo, String rc, String dirfi) {

File dirf=new File(dirfi);
List<String>cns=new ArrayList<>();
int fno=dirf.listFiles().length; int i=0;
int j;
int k=0;
String fStr,nolo,norc,unw,nounw;
boolean hlo,hrc;



while(i<fno) {

  fStr=dirf.listFiles()[i].toString();
  hlo=fStr.contains(lo);
  hrc=fStr.contains(rc);
  unw="";
  

  if(hlo==true&&hrc==true) {

    nolo=fStr.replace(lo,"");
    if(nolo.contains(")")){
  unw+=nolo.substring(0,nolo.lastIndexOf("(")+1);
  }
    
    norc=nolo.replace(rc,"");
    nounw=norc.replace(unw, "");
    boolean hasallint=isint(nounw);
    
    if(hasallint==true)
    cns.add(nounw);

  }

  i++;

}
 
for(String cn:cns) {

  j=Integer.parseInt(cn);

  if(j>k)  {

    k=j;

  }

}

return lo+(k+1)+rc;

}


public static boolean isint(String check){

  boolean allint=false;

  List<String>chars=new ArrayList<>();

  for(int st=0;st<check.length();st++){

      int charv=Integer.valueOf(check.charAt(st));

      if(charv>57||charv<48){

chars.add(charv+"");

}
}

  int chsz=chars.toArray().length;


   if(chsz<1){

       allint=true;

     }else{

       allint=false;

    }




  return allint;

}


public static void wipeFile(String file2wipe) throws IOException,  FileNotFoundException {

File f2w = new File(file2wipe);

 if (f2w.exists())
{

SecureRandom sr = new SecureRandom();
RandomAccessFile raf = new RandomAccessFile(f2w, "rw");
FileChannel channel = raf.getChannel();
MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_WRITE, 0, raf.length());

			while (buffer.hasRemaining())
			{
				buffer.put((byte) 0);
			}
			buffer.force();
			buffer.rewind();
			
			while (buffer.hasRemaining())
			{
			    buffer.put((byte) 0xFF);
			}
			buffer.force();
			buffer.rewind();
			
			byte[] data = new byte[1];
			while (buffer.hasRemaining())
			{
			    sr.nextBytes(data);
			    buffer.put(data[0]);
			}
			buffer.force();
		    raf.close();
			f2w.delete(); 
		 }
	}
	

 
public static void main(String [] args) throws IOException
{
//fileIndexer.wipeFile("storage/emulated/0/zuka (1).pdf");
    String folder,filename;
    //File newfile;
    
    
    folder = "C:\\a";
    filename = "a (17).pdf";
    String createdFile=fileIndexer.namefile("C:\\Users\\Tony Miract\\Desktop", "image4Desc.txt");
    System.out.println(createdFile);
    //newfile=new File(fileIndexer.namefile(folder, filename));
    if(new File(createdFile).createNewFile()){
        System.out.println("New file "+createdFile+" created successfully");
    }
    
}
}